#if !defined(GDK_PIXBUF_DISABLE_DEPRECATED) || defined(GDK_PIXBUF_COMPILATION)
/* This file is generated, all changes will be lost */
#ifndef ___GDK_PIXBUF_MARSHAL_MARSHAL_H__
#define ___GDK_PIXBUF_MARSHAL_MARSHAL_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* VOID:VOID (./gdk-pixbuf-marshal.list:25) */
#define _gdk_pixbuf_marshal_VOID__VOID	g_cclosure_marshal_VOID__VOID

/* VOID:INT,INT (./gdk-pixbuf-marshal.list:26) */
G_BEGIN_DECLS
extern
void _gdk_pixbuf_marshal_VOID__INT_INT (GClosure     *closure,
                                        GValue       *return_value,
                                        guint         n_param_values,
                                        const GValue *param_values,
                                        gpointer      invocation_hint,
                                        gpointer      marshal_data);
G_END_DECLS

/* VOID:INT,INT,INT,INT (./gdk-pixbuf-marshal.list:27) */
G_BEGIN_DECLS
extern
void _gdk_pixbuf_marshal_VOID__INT_INT_INT_INT (GClosure     *closure,
                                                GValue       *return_value,
                                                guint         n_param_values,
                                                const GValue *param_values,
                                                gpointer      invocation_hint,
                                                gpointer      marshal_data);
G_END_DECLS

/* VOID:POINTER (./gdk-pixbuf-marshal.list:28) */
#define _gdk_pixbuf_marshal_VOID__POINTER	g_cclosure_marshal_VOID__POINTER


G_END_DECLS

#endif /* ___GDK_PIXBUF_MARSHAL_MARSHAL_H__ */
#endif /* !GDK_PIXBUF_DISABLE_DEPRECATED || GDK_PIXBUF_COMPILATION */
