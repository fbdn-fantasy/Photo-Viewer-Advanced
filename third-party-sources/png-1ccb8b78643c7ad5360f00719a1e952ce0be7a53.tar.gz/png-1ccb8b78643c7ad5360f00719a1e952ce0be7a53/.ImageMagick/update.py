#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "Tools"))

from dependency_updater import Step, Updater

URL = "https://github.com/pnggroup/libpng/archive/refs/tags/v{version}.tar.gz"


def update_source(updater):
    updater.replace_source()
    updater.remove(".github")
    updater.update_config()


def create_header(updater):
    updater.copy("scripts/pnglibconf.h.prebuilt", "pnglibconf.h")
    updater.force_add("pnglibconf.h")


updater = Updater(__file__, "libpng", URL)
updater.run([
    Step("Replace the source with the release and update Config.txt", update_source,
        "Updated libpng to {version}"),
    Step("Copy scripts/pnglibconf.h.prebuilt to pnglibconf.h", create_header,
        "Copied scripts/pnglibconf.h.prebuilt to pnglibconf.h."),
    updater.clone_dependencies_step(),
])
