/*
  Copyright @ 1999 ImageMagick Studio LLC, a non-profit organization
  dedicated to making software imaging solutions freely available.

  You may not use this file except in compliance with the License.  You may
  obtain a copy of the License at

    https://imagemagick.org/license/

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

  MagickCore private image constitute methods.
*/
#ifndef MAGICKCORE_CONSTITUTE_PRIVATE_H
#define MAGICKCORE_CONSTITUTE_PRIVATE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#include "MagickCore/constitute.h"
#include "MagickCore/exception.h"
#include "MagickCore/log.h"
#include "MagickCore/magick.h"
#include "MagickCore/magick-private.h"
#include "MagickCore/utility.h"

extern MagickExport Image
  *ReadImageWithoutPostProcessing(const ImageInfo *,ExceptionInfo *);

static inline MagickBooleanType CheckCoderDepth(ImageInfo *image_info,
  ExceptionInfo *exception)
{
#define MagickMaxCoderDepth  128

  if (image_info->coder_depth++ >= MagickMaxCoderDepth)
    {
      errno=EPERM;
      (void) ThrowMagickException(exception,GetMagickModule(),OptionError,
        "ImageNestedTooDeeply","`%s'",image_info->filename);
      return(MagickFalse);
    }
  return(MagickTrue);
}

static inline Image *StrictReadImage(ImageInfo *image_info,
  ExceptionInfo *exception)
{
  char
    magic[MagickPathExtent];

  if (CheckCoderDepth(image_info,exception) == MagickFalse)
    return((Image *) NULL);
  (void) GetPathComponent(image_info->filename,MagickPath,magic);
  if (*magic != '\0')
    {
      const MagickInfo *magick_info = GetMagickInfo(magic,exception);
      if ((magick_info != (const MagickInfo *) NULL) &&
          (GetMagickExplicitAllowed(magick_info) != MagickFalse))
          return(ReadImage(image_info,exception));
      else
        {
          (void) ThrowMagickException(exception,GetMagickModule(),ImageError,
            "ExplicitCoderNotAllowed","`%s'",image_info->filename);
          return((Image *) NULL);
        }
    }
  if (IsPathAccessible(image_info->filename) == MagickFalse)
    {
      (void) ThrowMagickException(exception,GetMagickModule(),FileOpenError,
        "UnableToOpenFile","`%s'",image_info->filename);
      return((Image *) NULL);
    }
  return(ReadImage(image_info,exception));
}

static inline Image *StrictReadInlineImage(ImageInfo *image_info,
  const char *content,ExceptionInfo *exception)
{
  if (CheckCoderDepth(image_info,exception) == MagickFalse)
    return((Image *) NULL);
  return(ReadInlineImage(image_info,content,exception));
}

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif

#endif
